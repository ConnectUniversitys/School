#from replit import db
from flask import Flask, render_template, request, redirect

app = Flask("app")

@app.route("/")
def index():
  return render_template("index.html")

@app.route("/about")
def about():
  return render_template("about.html")

@app.route("/courses")
def courses():
  return render_template("courses.html")

@app.route("/news")
def news():
  return render_template("news.html")

@app.route("/instructors")
def instructors():
  return render_template("lecturers.html")

@app.route("/register", methods=["GET","POST"])
def register():
  error = ""
  if request.method == "POST":
    data = dict(request.form)
    if data['password'] == data['repeat']:
      username = data.pop('username')
      if username not in db:
        db[username] = data
        return redirect('login')
      else:
        error = "alert(\"User already registered.\")"
    else:
      error = "alert(\"Error: Passwords do not match.\");"

  return render_template("registration.html", error=error)

@app.route("/login", methods=["GET","POST"])
def login():
  error = ""

  if request.method == "POST":
    data = dict(request.form)
    if data['username'] in db:
      if db[data['username']]['password'] == data['password']:
        return redirect("/")

    error = "alert(\"Username or password invalid.\");"

  return render_template("login.html", error=error)

@app.route("/contact")
def contact():
  return render_template("contact.html")
if __name__ == "__main__":
  app.run("0.0.0.0",port=8080)
